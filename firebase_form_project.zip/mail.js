import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase, ref, push, set } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyCLuminpUmMalhgTY86vHNhfKHBmD3FV7w",
  authDomain: "cc-quiz-3bd7e.firebaseapp.com",
  databaseURL: "https://ccmcq-quiz-default-rtdb.firebaseio.com",
  projectId: "cc-quiz-3bd7e",
  storageBucket: "cc-quiz-3bd7e.firebasestorage.app",
  messagingSenderId: "658492569940",
  appId: "1:658492569940:web:ca6f46b406df3ebd0c30c1"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const dept = document.getElementById("dept").value;
  const deptNumber = document.getElementById("deptNumber").value;
  const emailid = document.getElementById("emailid").value;

  const newEntryRef = push(ref(db, "contactForm"));
  set(newEntryRef, {
    name: name,
    dept: dept,
    deptNumber: deptNumber,
    emailid: emailid
  });

  document.querySelector(".alert").style.display = "block";
  setTimeout(() => {
    document.querySelector(".alert").style.display = "none";
  }, 3000);

  document.getElementById("contactForm").reset();
});